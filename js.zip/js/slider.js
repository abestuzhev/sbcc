$(document).ready(function() {
  $('.main-slider').slick({
    dots: true,
    arrows: false,
    infinite: true,
    lazyLoad: "progressive",
    autoplay: true,
    autoplayspeed: 2000,
    slidesToShow: 1

  });

});
